/* form v)lid)tion */
function checkForm(selector) {
	$(selector).validate({ 
		rules: {
			name: {
				required: true,
				minlength: 8,
			},
			email: {
				required: true,
				email: true 
			},
			phoneUS: {
				required: true,
				phone: true,
			},
			message: {
				required: true
			}
		}, 
		messages: {
			name: {
				required: '*Please enter your full name', 
				minlength: '*Please enter your full name', 
				notEqualTo: '*Please enter your full name'
			},
			email: '*Please enter a valid email address', 
			phone: '*Please enter a valid phone number',
			message: '*Please tell us why you are interested in Neurofeedback'
		} 
	});
	return true; 
}

/*Inside Document Ready*/

$(document).ready(function() {
	/* form check and submit with ajaxiness */
	$('#formContainer').on('click', 'form#contactForm button:submit', function(e){
		checkForm('#contactForm'); 
		e.preventDefault();
		if ($('#contactForm').valid() == true) {
			var nameVal = $('#name').val();
			var emailFromVal = $('#email').val();
			var phoneVal = $('#phone').val();
			var howToContactVal = $('input[name="howToContact"]:radio:checked').val();
			var newToNFVal = $('select option:selected').val();
			var messageVal = $('#message').val();
			// console.log(howToContactVal, newToNFVal);
			$.post('contact.php',
				{ name: nameVal, email: emailFromVal, phone: phoneVal, howToContact: howToContactVal, newToNF: newToNFVal , message: messageVal },
				function(data){
					$('#contactForm').fadeOut('slow',
						function() {
							$('#thankYou').html('<p>Success.</p><p>Thank you for your email. We look forward to connecting with you.</p>');
						} 
					);
				}
			);
		} else {
			$('#thankYou').fadeIn('fast',
				function() {
					$('#thankYou').html('<p class="error"><b>*Please check for errors in the form</b></p>');
				}
			);
		}
		return false; 
	});
})










