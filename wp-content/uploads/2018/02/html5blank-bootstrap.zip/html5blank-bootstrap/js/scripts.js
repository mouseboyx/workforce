(function ($, root, undefined) {
	
	$(function () {
		
		'use strict';
		// DOM ready, take it away
		
	});
	
})(jQuery, this);

function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}


